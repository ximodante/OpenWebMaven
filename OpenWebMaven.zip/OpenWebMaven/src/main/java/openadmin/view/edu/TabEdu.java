package openadmin.view.edu;

import lombok.Getter;
import lombok.Setter;

public class TabEdu {
	
	@Getter @Setter
	private String className=null;  // Name of the class (JPA entity to display)
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
