package openadmin.view.edu;

public enum ElementTypeEdu {
	FORM,
    PANEL,
    TAB,
    FIELD
}	
