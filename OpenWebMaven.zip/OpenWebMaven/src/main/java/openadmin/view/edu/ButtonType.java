package openadmin.view.edu;

public enum ButtonType {
	Button,
	CommandButton,
	CommandLink,
	Link,
	SplitButton
}
