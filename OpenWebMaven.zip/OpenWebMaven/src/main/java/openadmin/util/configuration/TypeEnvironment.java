package openadmin.util.configuration;

public enum TypeEnvironment {

	WEB, SWING, PDA;
}
