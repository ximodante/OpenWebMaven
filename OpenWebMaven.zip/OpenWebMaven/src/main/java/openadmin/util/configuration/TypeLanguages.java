package openadmin.util.configuration;

	public enum TypeLanguages {

		es, ca;

	}

